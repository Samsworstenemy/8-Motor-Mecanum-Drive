// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;

import frc.robot.Constants;
import edu.wpi.first.wpilibj2.command.CommandBase;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.MecanumDriveKinematics;
import edu.wpi.first.math.kinematics.MecanumDriveOdometry;
import edu.wpi.first.math.kinematics.MecanumDriveWheelPositions;
import edu.wpi.first.math.kinematics.MecanumDriveWheelSpeeds;
import edu.wpi.first.networktables.GenericEntry;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.shuffleboard.Shuffleboard;
import edu.wpi.first.wpilibj.shuffleboard.ShuffleboardTab;
import edu.wpi.first.wpilibj.shuffleboard.SimpleWidget;
import edu.wpi.first.wpilibj.smartdashboard.Field2d;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

import com.revrobotics.CANSparkMaxLowLevel.MotorType;
import com.revrobotics.CANSparkMax.ControlType;
import com.revrobotics.CANSparkMax;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.SparkMaxPIDController;


public class DriveSubsystem extends SubsystemBase {
  // :> Create motor objects
  private final CANSparkMax frontLeftMotor1 = new CANSparkMax(Constants.Drivetrain.MotorFL1ID, MotorType.kBrushless);
  //private final CANSparkMax frontLeftMotor2 = new CANSparkMax(Constants.Drivetrain.MotorFL2ID, MotorType.kBrushless);
  private final CANSparkMax frontRightMotor1 = new CANSparkMax(Constants.Drivetrain.MotorFR1ID, MotorType.kBrushless);
  //private final CANSparkMax frontRightMotor2 = new CANSparkMax(Constants.Drivetrain.MotorFR2ID, MotorType.kBrushless);
  private final CANSparkMax backLeftMotor1 = new CANSparkMax(Constants.Drivetrain.MotorBL1ID, MotorType.kBrushless);
  //private final CANSparkMax backLeftMotor2 = new CANSparkMax(Constants.Drivetrain.MotorBL2ID, MotorType.kBrushless);
  private final CANSparkMax backRightMotor1 = new CANSparkMax(Constants.Drivetrain.MotorBR1ID, MotorType.kBrushless);
  //private final CANSparkMax backRightMotor2 = new CANSparkMax(Constants.Drivetrain.MotorBR2ID, MotorType.kBrushless);
  // :> Create encoder objects
  private final RelativeEncoder frontLeftEncoder1;
  //private final RelativeEncoder frontLeftEncoder2;
  private final RelativeEncoder frontRightEncoder1;
  //private final RelativeEncoder frontRightEncoder2;
  private final RelativeEncoder backLeftEncoder1;
  //private final RelativeEncoder backLeftEncoder2;
  private final RelativeEncoder backRightEncoder1;
  //private final RelativeEncoder backRightEncoder2;



  // :> Create PIDController objects
  private final SparkMaxPIDController frontLeftPIDController1;
  //private final SparkMaxPIDController frontLeftPIDController2;
  private final SparkMaxPIDController frontRightPIDController1;
  //private final SparkMaxPIDController frontRightPIDController2;
  private final SparkMaxPIDController backLeftPIDController1;
  //private final SparkMaxPIDController backLeftPIDController2;
  private final SparkMaxPIDController backRightPIDController1;
  //private final SparkMaxPIDController backRightPIDController2;
  // :> Makes the field object for shuffleboard and drive simulation
  static Field2d field = new Field2d();

    // :> Object that keeps track of robot position
    // :> Huge note that 6.0 and 4.0 number are very big place holders and need to be changed once
    // :> we do autonomous.
    Pose2d pose = new Pose2d(6.0, 4.0, new Rotation2d());
    double frontLeftTarget;
    double frontRightTarget;
    double backLeftTarget;
    double backRightTarget;

    double angle;
    boolean higherspeed = true;

    // :> Mec Drive Kinematics Objects that will be used to calculate wheel speeds and positions on the robot.
    MecanumDriveKinematics kinematics = new MecanumDriveKinematics(
    Constants.Drivetrain.frontLeftMeters, 
    Constants.Drivetrain.frontRightMeters, 
    Constants.Drivetrain.backLeftMeters, 
    Constants.Drivetrain.backRightMeters
  );
  // ~~ mecanum drive odometry object for calculating position of robot based on wheel speeds
  MecanumDriveOdometry odometry;
  // :> I miss Gabe ):
  
  // :> Make sure to feed the Shuffleboard Goblin
  private final ShuffleboardTab pidTab = Shuffleboard.getTab("PID Tuning");
  public GenericEntry pGain;
  public GenericEntry iGain;
  public GenericEntry dGain;
  public GenericEntry speedErrorThreshold;
  
  private SimpleWidget pGainWidget;
  private SimpleWidget iGainWidget;
  private SimpleWidget dGainWidget;
  private SimpleWidget speedErrorThresholdWidget;
  
  private double xChange = 0.0;
  private double yChange = 0.0;
    

  public DriveSubsystem() {

    // :> It's inverting time
    frontLeftMotor1.setInverted(true);
    //frontLeftMotor2.setInverted(true);
    backLeftMotor1.setInverted(true);
    //backLeftMotor2.setInverted(true);
    frontRightMotor1.setInverted(false);
    //frontRightMotor2.setInverted(false);
    backRightMotor1.setInverted(false);
    //backRightMotor2.setInverted(false);
    // :> In testing only the FL and BL needed to be inverted.
    // :> Fix as needed if things start conflicting. Remember the drive train is weird.

    // :> Sets the encoder objects to the physical motor encoders
    frontLeftEncoder1 = frontLeftMotor1.getEncoder();
    //frontLeftEncoder2 = frontLeftMotor2.getEncoder();
    backLeftEncoder1 = backLeftMotor1.getEncoder();
    //backLeftEncoder2 = backLeftMotor2.getEncoder();
    frontRightEncoder1 = frontRightMotor1.getEncoder();
    //frontRightEncoder2 = frontRightMotor2.getEncoder();
    backRightEncoder1 = backRightMotor1.getEncoder();
    //backRightEncoder2 = backRightMotor2.getEncoder();

    // :> Getting Velocity and Position conversation factor for later
    frontLeftEncoder1.setVelocityConversionFactor(Constants.Drivetrain.velocityConversionRatio);
    //frontLeftEncoder2.setVelocityConversionFactor(Constants.Drivetrain.velocityConversionRatio);
    frontRightEncoder1.setVelocityConversionFactor(Constants.Drivetrain.velocityConversionRatio);
    //frontRightEncoder2.setVelocityConversionFactor(Constants.Drivetrain.velocityConversionRatio);
    backLeftEncoder1.setVelocityConversionFactor(Constants.Drivetrain.velocityConversionRatio);
    //backLeftEncoder2.setVelocityConversionFactor(Constants.Drivetrain.velocityConversionRatio);
    backRightEncoder1.setVelocityConversionFactor(Constants.Drivetrain.velocityConversionRatio);
    //backRightEncoder2.setVelocityConversionFactor(Constants.Drivetrain.velocityConversionRatio);

    frontLeftEncoder1.setPositionConversionFactor(Constants.Drivetrain.positionConversionRation);
    //frontLeftEncoder2.setPositionConversionFactor(Constants.Drivetrain.positionConversionRation);
    frontRightEncoder1.setPositionConversionFactor(Constants.Drivetrain.positionConversionRation);
    //frontRightEncoder2.setPositionConversionFactor(Constants.Drivetrain.positionConversionRation);
    backLeftEncoder1.setPositionConversionFactor(Constants.Drivetrain.positionConversionRation);
    //backLeftEncoder2.setPositionConversionFactor(Constants.Drivetrain.positionConversionRation);
    backRightEncoder1.setPositionConversionFactor(Constants.Drivetrain.positionConversionRation);
    //backRightEncoder2.setPositionConversionFactor(Constants.Drivetrain.positionConversionRation);

    // :> Makes our PID Controller object the actual PID Controller on the motor
    frontLeftPIDController1 = frontLeftMotor1.getPIDController();
    //frontLeftPIDController2 = frontLeftMotor2.getPIDController();
    frontRightPIDController1 = frontRightMotor1.getPIDController();
    //frontRightPIDController2 = frontRightMotor2.getPIDController();
    backLeftPIDController1 = backLeftMotor1.getPIDController();
    //backLeftPIDController2 = backLeftMotor2.getPIDController();
    backRightPIDController1 = backRightMotor1.getPIDController();
    //backRightPIDController2 = backRightMotor2.getPIDController();

    frontRightPIDController1.setFeedbackDevice(frontRightEncoder1);
    backRightPIDController1.setFeedbackDevice(backRightEncoder1);
    frontLeftPIDController1.setFeedbackDevice(frontLeftEncoder1);
    backLeftPIDController1.setFeedbackDevice(backLeftEncoder1);

    // :> ShuffleBoard stuff designed to make it so we can change PIDs easier
    pGainWidget = pidTab.add("P gain", Constants.Drivetrain.teleopPGain);
    iGainWidget = pidTab.add("I gain", Constants.Drivetrain.teleopIGain);
    dGainWidget = pidTab.add("D gain", Constants.Drivetrain.teleopDGain);
    speedErrorThresholdWidget = pidTab.add("Speed Error Tolerance", 0.1);
  
    // :> Feed the position goblin
    resetPose(0.0, 0.0, 0.0);

    // :> Odometry with pose isn't working properly so everytime we need wheel positions or pose I've put the encoder positions instead
    odometry = new MecanumDriveOdometry(kinematics, new Rotation2d(angle),  new MecanumDriveWheelPositions(frontLeftEncoder1.getPosition(), frontRightEncoder1.getPosition(), backLeftEncoder1.getPosition(), backRightEncoder1.getPosition()));
    // :> I swear if the above method is why it's having a PID seisure I am going to kick Brinkley
    frontLeftTarget = 0.0;
    frontRightTarget = 0.0;
    backLeftTarget = 0.0;
    backRightTarget = 0.0;
  }
  
  // :> ALL OF THE IMPORTANT DRIVING STUFF
  // :> Okay so since setVelocityReference can only take in 4 arguments and we still want to accelerate in 4 and change to 8 we need to do the following:
    // :> For 8 we pass in 4 and set the extra 4 of them to be the same as the normal 4
    // :> For 4 we pass in 4 and set 4 to disable and set the other 4 to full power.
    // :> This all needs to rigourously be tested and edited in command.
  public void setVelocityReferenceAll8(double flRef, double blRef, double frRef, double brRef) {
    frontLeftPIDController1.setReference(flRef, ControlType.kVelocity);
    //frontLeftPIDController2.setReference(flRef, ControlType.kVelocity);
    frontRightPIDController1.setReference(frRef, ControlType.kVelocity);
    //frontRightPIDController2.setReference(frRef, ControlType.kVelocity);
    backLeftPIDController1.setReference(blRef, ControlType.kVelocity);
    //backLeftPIDController2.setReference(blRef, ControlType.kVelocity);
    backRightPIDController1.setReference(brRef, ControlType.kVelocity);
    //backRightPIDController2.setReference(brRef, ControlType.kVelocity);

    System.out.print(flRef);
    System.out.print(blRef);
    System.out.print(frRef);
    System.out.print(brRef);

    if (DriverStation.isTeleopEnabled()) {
      SmartDashboard.putNumber("FL target speed", flRef);
      SmartDashboard.putNumber("FR target speed", frRef);
      SmartDashboard.putNumber("BL target speed", blRef);
      SmartDashboard.putNumber("BR target speed", brRef);

      SmartDashboard.putNumber("FL ACTUAL speed", frontLeftEncoder1.getVelocity());
      SmartDashboard.putNumber("FR ACTUAL speed", frontRightEncoder1.getVelocity());
      SmartDashboard.putNumber("BL ACTUAL speed", backLeftEncoder1.getVelocity());
      SmartDashboard.putNumber("BR ACTUAL speed", backRightEncoder1.getVelocity());


    }
  }
  
  public void setVelocityReferenceAll8(MecanumDriveWheelSpeeds wheelSpeeds) {
    setVelocityReferenceAll8(
      wheelSpeeds.frontLeftMetersPerSecond,
      wheelSpeeds.rearLeftMetersPerSecond,
      wheelSpeeds.frontRightMetersPerSecond,
      wheelSpeeds.rearRightMetersPerSecond 
    );
  }

  // :> We don't need to accelerate in 4 so ignore anything with the 4 or 8.

  // :> We don't need to care for accelerating in 4 for position so instead we just pass in 4 and set the extra 4 to the other 4
  // :> Sets the positional References to the wheelPositions
  public void setPositionalReference(double flRef, double frRef, double blRef, double brRef) {
    frontLeftPIDController1.setReference(flRef, ControlType.kPosition);
    //frontLeftPIDController2.setReference(flRef, ControlType.kPosition);
    frontRightPIDController1.setReference(frRef, ControlType.kPosition);
    //frontRightPIDController2.setReference(frRef, ControlType.kPosition);
    backLeftPIDController1.setReference(blRef, ControlType.kPosition);
    //backLeftPIDController2.setReference(blRef, ControlType.kPosition);
    backRightPIDController1.setReference(brRef, ControlType.kPosition);
    //backRightPIDController2.setReference(brRef, ControlType.kPosition);

    frontLeftTarget = flRef;
    frontRightTarget = frRef;
    backLeftTarget = blRef;
    backRightTarget = brRef;
  }

  public void setPositionalReference(MecanumDriveWheelSpeeds wheelPositions) {
    setPositionalReference(
      wheelPositions.frontLeftMetersPerSecond,
      wheelPositions.frontRightMetersPerSecond,
      wheelPositions.rearLeftMetersPerSecond,
      wheelPositions.rearRightMetersPerSecond
    );
  }

  // :> PID time
  // :> Sets the P I and D gain for all the motors
  public void setPIDValues(double kP, double kI, double kD) {
    frontLeftPIDController1.setP(kP);
    frontLeftPIDController1.setI(kI);
    frontLeftPIDController1.setD(kD);

    //frontLeftPIDController2.setP(kP);
    //frontLeftPIDController2.setI(kI);
    //frontLeftPIDController2.setD(kD);
    
    frontRightPIDController1.setP(kP);
    frontRightPIDController1.setI(kI);
    frontRightPIDController1.setD(kD);

    //frontRightPIDController2.setP(kP);
    //frontRightPIDController2.setI(kI);
    //frontRightPIDController2.setD(kD);
    
    backLeftPIDController1.setP(kP);
    backLeftPIDController1.setI(kI);
    backLeftPIDController1.setD(kD);
    
    //backLeftPIDController2.setP(kP);
    // backLeftPIDController2.setI(kI);
    //backLeftPIDController2.setD(kD);

    backRightPIDController1.setP(kP);
    backRightPIDController1.setI(kI);
    backRightPIDController1.setD(kD);

    //backRightPIDController2.setP(kP);
    //backRightPIDController2.setI(kI);
    //backRightPIDController2.setD(kD);

    frontLeftPIDController1.setIAccum(0);
    //frontLeftPIDController2.setIAccum(0);
    frontRightPIDController1.setIAccum(0);
    //frontRightPIDController2.setIAccum(0);
    backLeftPIDController1.setIAccum(0);
    //backLeftPIDController2.setIAccum(0);
    backRightPIDController1.setIAccum(0);
    //backRightPIDController2.setIAccum(0);


    // :> Y'know I'm starting to get real tired of typing out the same line over and over again just to change a 1 to a 2 or writing in a 1 and a 2
  }
  
  // :> Feed the ease of use Shuffleboard demon
  public void getShuffleboardPID() {
    pGain = pGainWidget.getEntry();
    iGain = iGainWidget.getEntry();
    dGain = dGainWidget.getEntry();
  }

  // :> The following methods get each of the wheel speeds indiviudally. This is very important
  // :> Gets the kinematics object for the inverse kinematics for commands later
  public MecanumDriveWheelSpeeds toWheelSpeeds(ChassisSpeeds robotSpeed) {
    return kinematics.toWheelSpeeds(robotSpeed);
  }
  
  public ChassisSpeeds getTeleopChassisSpeed(double x, double y, double r) {
    // :> Outputs wheels speed object based off of X, Y and rotation values
    System.out.print("X:");
    System.out.print(x);
    System.out.print("Y:");
    System.out.print(y);
    System.out.print("R:");
    System.out.println(r);
    ChassisSpeeds vehicleSpeed = new ChassisSpeeds(y, x, r);
      return vehicleSpeed;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
  }

  // :> 2022 Maya's explanation of this next two methods is much better than anything I can come up with so I will literally just slap it in
  
  /**
   * ++ this takes x, y, and r values (maybe from controller) 
   * and creates a wheelSpeeds object, which can then be used to set PIDs etc.
   * 
   * (this explination thing might also be broken; it's just a test to figure out how it works)
   *
   * @param x x velocity
   * @param y y velocity
   * @param r rotation
   * @return a wheelSpeeds object
   */
  public MecanumDriveWheelSpeeds getWheelSpeeds(double x, double y, double r) {
    ChassisSpeeds vehicleSpeed = getTeleopChassisSpeed(x, y, r);
    MecanumDriveWheelSpeeds wheelSpeeds = toWheelSpeeds(vehicleSpeed);
    wheelSpeeds.desaturate(Constants.Drivetrain.maxWheelSpeed);
    return wheelSpeeds;
  }

  /**
   * ++ this is an all-in-one drivetrain method- just give it x, y, and r, and it sets the wheel speeds
   * this method composes previous drive methods. 
   * [ getWheelSpeeds() and then setVelocityReference() ]
   * @param x x velocity
   * @param y y velocity
   * @param r rotation
   */
  public void setReferencesFromWheelSpeeds(double x, double y, double r){
    /* ++ the getWheelSpeeds() method returns a MecanumDriveWheelSpeeds object, 
    *  and setVelocityReference() takes a MecanumDriveWheelSpeeds object and sets
    *  the reference speeds of the wheels
    */
    if (higherspeed = true) {
      setVelocityReferenceAll8(getWheelSpeeds(x, y, r));
    }
    // :> This used to have other code I don't want to break anything right now so I am just going to say if true grin.
  }
  // :> this is been modified so that later when we are testing starting in 4 and switching to eight that it becomes possible
  // :> Currently it is set to always accelerate in eight but later it will be fixed
  // :> Do not confuse this with fast mode in which 200 amps will be thrown at the motors as that we are accelerating in eight in a very different way

  // :> Resets all positional data
  public void resetPose(Pose2d newPose) {
    IMUSubsystem.setYaw(newPose.getRotation().getDegrees());
    pose = newPose;
    angle = pose.getRotation().getRadians();
    odometry = new MecanumDriveOdometry(kinematics, new Rotation2d(angle),  new MecanumDriveWheelPositions(frontLeftEncoder1.getPosition(), frontRightEncoder1.getPosition(), backLeftEncoder1.getPosition(), backRightEncoder1.getPosition()));
    // :> so odometry = new MecanumDriveOdometry(kinematics, new Rotation2d(angle), pose); didn't work so I did a silly goofy and manually changed
    // :> it so that it gets the encoder values to make it work. This should theoretically work but y'know it's a little silly goofy
    // :< new MecanumDriveWheelPositions(
      /*frontLeftEncoder1.getPosition(), frontRightEncoder1.getPosition(), backLeftEncoder1.getPosition(), backRightEncoder1.getPosition()),
     *setPositionalReference(0.0, 0.0, 0.0, 0.0);
    */
    frontLeftEncoder1.setPosition(0.0);
    //frontLeftEncoder2.setPosition(0.0);
    frontRightEncoder1.setPosition(0.0);
    //frontRightEncoder2.setPosition(0.0);
    backLeftEncoder1.setPosition(0.0);
    //backLeftEncoder2.setPosition(0.0);
    backRightEncoder1.setPosition(0.0);
    //backRightEncoder2.setPosition(0.0);
  }

  public void resetPose(double x, double y, double r) {
    resetPose(new Pose2d(x, y, new Rotation2d(r)));
  }

  public void changeRobotPosition(Pose2d transform) {
    ChassisSpeeds chassisPos = new ChassisSpeeds(transform.getX(), transform.getY(), 0);
    MecanumDriveWheelSpeeds wheelPos = kinematics.toWheelSpeeds(chassisPos);

    frontLeftPIDController1.setOutputRange(-0.2, 0.2);
    //frontLeftPIDController2.setOutputRange(-0.2, 0.2);
    frontRightPIDController1.setOutputRange(-0.2, 0.2);
    //frontRightPIDController2.setOutputRange(-0.2, 0.2);
    backLeftPIDController1.setOutputRange(-0.2, 0.2);
    //backLeftPIDController2.setOutputRange(-0.2, 0.2);
    backRightPIDController1.setOutputRange(-0.2, 0.2);
    //backRightPIDController2.setOutputRange(-0.2, 0.2);
    frontLeftEncoder1.setPosition(0.0);
    //frontLeftEncoder2.setPosition(0.0);
    frontRightEncoder1.setPosition(0.0);
    //frontRightEncoder2.setPosition(0.0);
    backLeftEncoder1.setPosition(0.0);
    //backLeftEncoder2.setPosition(0.0);
    backRightEncoder1.setPosition(0.0);
    //backRightEncoder2.setPosition(0.0);

    setPositionalReference(wheelPos);
  }

// // ~~ sets the absolute robot position
public void setRobotPosition(Pose2d position) {
  Pose2d transform = new Pose2d(position.getX() - pose.getX(), position.getY() - pose.getY(), new Rotation2d(0.0));
  changeRobotPosition(transform);
}

public void changeRobotAngle(double radians) {
  ChassisSpeeds chassisPos = new ChassisSpeeds(0,0, radians);
  MecanumDriveWheelSpeeds wheelPos = kinematics.toWheelSpeeds(chassisPos);

  frontLeftEncoder1.setPosition(0.0);
  //frontLeftEncoder2.setPosition(0.0);
  frontRightEncoder1.setPosition(0.0);
  //frontRightEncoder2.setPosition(0.0);
  backLeftEncoder1.setPosition(0.0);
  //backLeftEncoder2.setPosition(0.0);
  backRightEncoder1.setPosition(0.0);
  //backRightEncoder2.setPosition(0.0);

  setPositionalReference(wheelPos);
}

// :> More good Gabe explanations
// ~~ Sets the angle of the robot in radians from -π to π
public void setRobotAngle(double radians) {
  // ~~ Dumb math to make the angle of the robot continuous instead of linear 
  // ~~ (ie. being at π and rotating π radians puts you at 0, not 2π)
  // ~~ Also means the robot wont do a 360 just to turn from slightly left to slightly right
  Rotation2d currentRotation = IMUSubsystem.getGyroRotation();
  Rotation2d newRotation = new Rotation2d(radians);
  Rotation2d transform = newRotation.plus(new Rotation2d(currentRotation.getRadians() * -1));

  // if (lowestDif == standardDif) {
  //   changeRobotAngle(radians - currentAngle);
  // } else if (lowestDif == lowDif) {
  //   changeRobotAngle((radians + (2 * Math.PI)) - currentAngle);
  // }else {
  //   changeRobotAngle((radians + (2 * Math.PI)) - currentAngle);
  // }
  changeRobotAngle(transform.getRadians());
}

public void lookAt(Pose2d target) {
  Pose2d vector = target.relativeTo(pose);
  double radians = Math.atan2(vector.getY(), vector.getX());
  setRobotAngle(radians);
}

public boolean atTargetPosition() {
  double flError = Math.abs(frontLeftTarget - frontLeftEncoder1.getPosition());
  double frError = Math.abs(frontRightTarget - frontRightEncoder1.getPosition());
  double blError = Math.abs(backLeftTarget - backLeftEncoder1.getPosition());
  double brError = Math.abs(backRightTarget - backRightEncoder1.getPosition());

  double tolerance = Constants.Drivetrain.errorTolerance;
  boolean atTargetPosition = ((flError <= tolerance) || (frError <= tolerance) || (blError <= tolerance) || (brError <= tolerance));
  return atTargetPosition;
}

public void toTeleopMode() {
  double angle;
  if (IMUSubsystem.getYaw() >= 0) {
    angle = IMUSubsystem.getGyroRotation().getRadians();
  }else {
    angle = (2 * Math.PI) + IMUSubsystem.getGyroRotation().getRadians();
  }
  double xDif = -0.6604 * Math.cos(angle);
  double yDif = -0.6604 * Math.sin(angle);

  resetPose(pose.getX() + xDif, pose.getY() + yDif, pose.getRotation().getRadians());
}

public static Field2d getField() {
  return field;
}

  @Override
  public void periodic() {
    // This method will be called once per scheduler run
    xChange = IMUSubsystem.getXPosition() - xChange;
    yChange = IMUSubsystem.getYPosition() - yChange;

    MecanumDriveWheelSpeeds wheelspeeds = new MecanumDriveWheelSpeeds(
        frontLeftEncoder1.getVelocity(),
        frontRightEncoder1.getVelocity(),
        backLeftEncoder1.getVelocity(),
        backRightEncoder1.getVelocity()
    );

    speedErrorThreshold = speedErrorThresholdWidget.getEntry();
    // ~~ Use odometry object for calculating position
    ChassisSpeeds expectedSpeed = kinematics.toChassisSpeeds(wheelspeeds);
    ChassisSpeeds actualSpeed = new ChassisSpeeds(-IMUSubsystem.getZVelocity(), IMUSubsystem.getYVelocity(), 0.0);

    Double xError = expectedSpeed.vxMetersPerSecond - actualSpeed.vxMetersPerSecond;
    Double yError = expectedSpeed.vyMetersPerSecond - actualSpeed.vyMetersPerSecond;
    
    Double speedError = Math.sqrt(Math.pow(xError, 2) + Math.pow(yError, 2));

    if (DriverStation.isTest()) {
      SmartDashboard.putNumber("Speed Error", speedError);
    }

    // ~~ Checks if the robot's wheels are slipping to determine if odometry or the imu would be more accurate
    if (speedError < speedErrorThreshold.getDouble(0.1)) {
      // ~~ Calculates position based on odometry
      pose = odometry.update(new Rotation2d(angle),  new MecanumDriveWheelPositions(frontLeftEncoder1.getPosition(), frontRightEncoder1.getPosition(), backLeftEncoder1.getPosition(), backRightEncoder1.getPosition()));

      if (DriverStation.isTest()) {
        SmartDashboard.putBoolean("Slipping?", false);
      }
    } 
    else {
      // ~~ Calculates position based on imu
      Double newX = pose.getX() + xChange;
      Double newY = pose.getY() + yChange;
      Rotation2d newR = pose.getRotation();

      pose = new Pose2d(newX, newY, newR);

      // ~~ Updates odometry object with data from imu
      odometry.update(new Rotation2d(angle), new MecanumDriveWheelPositions(frontLeftEncoder1.getPosition(), frontRightEncoder1.getPosition(), backLeftEncoder1.getPosition(), backRightEncoder1.getPosition()));
      odometry.resetPosition(new Rotation2d(angle),  new MecanumDriveWheelPositions(frontLeftEncoder1.getPosition(), frontRightEncoder1.getPosition(), backLeftEncoder1.getPosition(), backRightEncoder1.getPosition()), pose);
      // :> odometry seems to not be workign like it was before??? It seems to want wheel positions so I'm just giving it the encoder positions
      SmartDashboard.putBoolean("Slipping?", true);

    }

    SmartDashboard.putNumber("Robot x", pose.getX());
    SmartDashboard.putNumber("Robot y", pose.getY());
    SmartDashboard.putNumber("Robot rotation", pose.getRotation().getDegrees());

    // :> This one isn't fully accurate but it shouldn't matter
    SmartDashboard.putNumber("FL Speed", frontLeftEncoder1.getVelocity());

    SmartDashboard.putNumber("FL Position", frontLeftEncoder1.getPosition());
    // ~~ Update field object for shuffleboard
    
    field.setRobotPose(pose);

  }

  @Override
  public void simulationPeriodic() {
    // This method will be called once per scheduler run during simulation
  }
}
