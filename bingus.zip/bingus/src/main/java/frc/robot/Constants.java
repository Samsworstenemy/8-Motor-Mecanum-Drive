// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.math.geometry.Translation2d;

/**
 * The Constants class provides a convenient place for teams to hold robot-wide numerical or boolean
 * constants. This class should not be used for any other purpose. All constants should be declared
 * globally (i.e. public static). Do not put anything functional in this class.
 *
 * <p>It is advised to statically import this class (or one of its inner classes) wherever the
 * constants are needed, to reduce verbosity.
 */

 // ££ I still don't understand why putting k in front of variables is the standard in WPILib
public final class Constants {


  /** ++ constants for JOYSTICKS -------------------------------------------- */
  public static final class Joysticks {
    public static final int primaryControllerID = 0;
    public static final int secondaryControllerID = 1;

    // ++ OTHER JOYSTICK CONSTANTS --
    public static final double deadZoneSize = 0.15;
    /**  ++ lowPassFilterStrength should be between 0 & 1. The closer it is to 1, the smoother acceleration will be. */
    public static final double driveLowPassFilterStrength = 0.91;
    public static final double rotationLowPassFilterStrength = 0.2;
    // ++ we probably don't want the speed damcursjdjdjdpers as finals incase we want a fastmode/to change them later 
    public static final double driveSpeedDamper = .9; 
    public static final double rotationDamper = 8.0; 

    // ss This is the multiplier for Fast Mode
    // explained in JoyUtil.java
    public static final double fastModeMaxMultiplier = 0.5;

    /** ++ the damper for the D-Pad inputs */
    public static final double dPadDamper = 0.7;


    // ++ JOYSTICK CURVE CONSTANTS --
    public static final double aCoeff = 0.7;
    public static final int firstPower = 3;

    public static final int secondPower = 1; 
    public static final double bCoeff = (1.0 - aCoeff); 


  }

    /** ++ constants for DRIVE TRAIN -------------------------------------------*/
    public static final class Drivetrain {
      // :> everything remotely drivetrain related for our constants will go in here.
      // :> Motor IDs on the CAN Bus
      public static final int MotorFL1ID = 4;
      //public static final int MotorFL2ID = 9;
      public static final int MotorBL1ID = 3;
      //public static final int MotorBL2ID = 11;
      public static final int MotorFR1ID = 5;
      //public static final int MotorFR2ID = 7;
      public static final int MotorBR1ID = 2;
      //public static final int MotorBR2ID = 2;
      
      // :> Mecanum wheel postions in meters.
      public static final Translation2d frontLeftMeters = new Translation2d(0.257175,0.254);
      public static final Translation2d frontRightMeters = new Translation2d(0.257175,-0.254);
      public static final Translation2d backLeftMeters = new Translation2d(-0.257175, 0.254);
      public static final Translation2d backRightMeters = new Translation2d(-0.257175,-0.254);
      
      // :> Wheel Radius in meters
      public static final double wheelDiameter = 0.1524;
      
      // :> Teleop PID values
      // :> This is a placeholder there is no way this is going to be the actual values
      public static final double teleopPGain = 0.17;
      public static final double teleopIGain = 0;
      public static final double teleopDGain = 0;
      
      // :> Crash detection threshold value
      public static final double speedErrorThreshold = 0.1;
      
      // :> This is crunching my brain so I'm going to let 2022 Maya take the wheel
      // ++ Motor conversion ratio stuff ------------------------------
      /**  ++ maximum RPM of the drivetrain NEOs (also the conversion factor from joystick input to RPM) */
      public static final double maxNEORPM = 5500.0;
      // ~~ Conversion ratios for drivetrain encoders
        /** ++ (velocity conversion) converts from RPM to meters per second, including gearboxes*/
      public static final double velocityConversionRatio = ((wheelDiameter * Math.PI)/(8.15 * 60));
        /** (position conversion) is the same as velocity conversion but has a cursed coefficient for some reason,,,
            * figure out what's going on with that constant */
      public static final double positionConversionRation = ((wheelDiameter * Math.PI)/(8.15));
      /**  maximum speed of robot in m/s (max rpm times conversion ratio), this also (I think) converts from RPM to m/s */
      public static final double maxWheelSpeed = maxNEORPM * velocityConversionRatio;
      /** error tolerance for wheel encoders during autnomous */
      public static final double errorTolerance = 0.2;
  
    }

  /** ++ constants for GRABBER ---------------------------------------------------------- */
  public static final class Grabber {

  }
   

  /** ++ constants for WRIST and ARM ---------------------------------------------------- */
  public static final class WristAndArm {

  }


  /** ++ constants for PHOTONVISION ----------------------------------------------------- */
  public static final class PhotonVision {

  }

  /** ++ constants for NEOs ------------------------------------------------------------- */
  public static final class NEOs{
    public static double maxNEORPM = 5500.0;
  }


}
  


